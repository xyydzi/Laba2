using System;

class Program
{
    // Проверяем, есть ли победитель
    static char CheckWinner(char[] board)
    {
        int[,] lines =
        {
            { 0, 1, 2 },
            { 3, 4, 5 },
            { 6, 7, 8 },
            { 0, 3, 6 },
            { 1, 4, 7 },
            { 2, 5, 8 },
            { 0, 4, 8 },
            { 2, 4, 6 }
        };

        for (int i = 0; i < 8; i++)
        {
            int a = lines[i, 0];
            int b = lines[i, 1];
            int c = lines[i, 2];

            if (board[a] != ' ' &&
                board[a] == board[b] &&
                board[b] == board[c])
            {
                return board[a];
            }
        }

        return ' ';
    }

    // Проверяем, заполнено ли поле
    static bool IsBoardFull(char[] board)
    {
        for (int i = 0; i < 9; i++)
        {
            if (board[i] == ' ')
                return false;
        }

        return true;
    }

    // Выводим игровое поле
    static void PrintBoard(char[] board)
    {
        Console.WriteLine();

        for (int i = 0; i < 9; i++)
        {
            if (board[i] == ' ')
                Console.Write(i + 1);
            else
                Console.Write(board[i]);

            if (i % 3 != 2)
                Console.Write(" | ");
            else if (i != 8)
                Console.WriteLine("\n--+---+--");
        }

        Console.WriteLine("\n");
    }

    // Алгоритм Minimax
    static int Minimax(char[] board, bool isMaximizing)
    {
        char winner = CheckWinner(board);

        if (winner == 'O')
            return 10;

        if (winner == 'X')
            return -10;

        if (IsBoardFull(board))
            return 0;

        if (isMaximizing)
        {
            int bestScore = -1000;

            for (int i = 0; i < 9; i++)
            {
                if (board[i] == ' ')
                {
                    board[i] = 'O';

                    int score = Minimax(board, false);

                    board[i] = ' ';

                    if (score > bestScore)
                        bestScore = score;
                }
            }

            return bestScore;
        }
        else
        {
            int bestScore = 1000;

            for (int i = 0; i < 9; i++)
            {
                if (board[i] == ' ')
                {
                    board[i] = 'X';

                    int score = Minimax(board, true);

                    board[i] = ' ';

                    if (score < bestScore)
                        bestScore = score;
                }
            }

            return bestScore;
        }
    }

    // Находим лучший ход ИИ
    static int FindBestMove(char[] board)
    {
        int bestScore = -1000;
        int bestMove = -1;

        for (int i = 0; i < 9; i++)
        {
            if (board[i] == ' ')
            {
                board[i] = 'O';

                int score = Minimax(board, false);

                board[i] = ' ';

                if (score > bestScore)
                {
                    bestScore = score;
                    bestMove = i;
                }
            }
        }

        return bestMove;
    }

    static void Main()
    {
        char[] board =
        {
            ' ', ' ', ' ',
            ' ', ' ', ' ',
            ' ', ' ', ' '
        };

        Console.WriteLine("Tic-Tac-Toe: Human (X) vs AI (O)");

        while (true)
        {
            PrintBoard(board);

            // Ход человека
            int move;

            while (true)
            {
                Console.Write("Choose a cell (1-9): ");
                string? input = Console.ReadLine();

                if (!int.TryParse(input, out move))
                {
                    Console.WriteLine("Enter a number from 1 to 9.");
                    continue;
                }

                if (move < 1 || move > 9 || board[move - 1] != ' ')
                {
                    Console.WriteLine("Invalid move. Try again.");
                    continue;
                }

                break;
            }

            board[move - 1] = 'X';

            if (CheckWinner(board) == 'X')
            {
                PrintBoard(board);
                Console.WriteLine("You win!");
                break;
            }

            if (IsBoardFull(board))
            {
                PrintBoard(board);
                Console.WriteLine("Draw!");
                break;
            }

            // Ход ИИ
            int aiMove = FindBestMove(board);
            board[aiMove] = 'O';

            Console.WriteLine($"AI chooses cell {aiMove + 1}");

            if (CheckWinner(board) == 'O')
            {
                PrintBoard(board);
                Console.WriteLine("AI wins!");
                break;
            }

            if (IsBoardFull(board))
            {
                PrintBoard(board);
                Console.WriteLine("Draw!");
                break;
            }
        }
    }
}
